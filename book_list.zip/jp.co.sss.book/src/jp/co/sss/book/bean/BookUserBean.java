package jp.co.sss.book.bean;

public class BookUserBean {

	private String bookUserId;
	private String bookUserName;
	private String password;

	public String getBookUserId() {
		return bookUserId;
	}
	public void setBookUserId(String bookUserId) {
		this.bookUserId = bookUserId;
	}
	public String getBookUserName() {
		return bookUserName;
	}
	public void setBookUserName(String bookUserName) {
		this.bookUserName = bookUserName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}


}
