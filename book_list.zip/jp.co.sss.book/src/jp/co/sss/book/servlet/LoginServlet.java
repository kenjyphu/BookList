package jp.co.sss.book.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.sss.book.bean.BookUserBean;
import jp.co.sss.book.dao.LoginDao;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	// Hien thi trang Login.
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Lay id va pass tu jsp. Sau an submit
		String bookUserId = request.getParameter("bookUserId");
		String password = request.getParameter("password");

		BookUserBean bookUser = null;
		try {
			bookUser = LoginDao.login(bookUserId, password);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (bookUser == null) {
			response.sendRedirect("http://localhost:55000/jp.co.sss.book/book/index.jsp");
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/BookList");
			dispatcher.forward(request, response);
		}

	}

	// Khi nguoi dung nhap id, pass. An submit
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
