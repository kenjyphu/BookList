package jp.co.sss.book.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.sss.book.bean.BookBean;
import jp.co.sss.book.dao.BookDao;

@WebServlet("/BookList")
public class BookList extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<BookBean> bookList = new ArrayList<>();

		bookList = BookDao.selectAll();

		// Luu
		request.setAttribute("bookList", bookList);

		//Forward
		RequestDispatcher dispatcher=
				request.getRequestDispatcher("/book/book_list.jsp");
		dispatcher.forward(request, response);
	}



}
