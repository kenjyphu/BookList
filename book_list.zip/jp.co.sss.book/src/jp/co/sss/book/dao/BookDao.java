package jp.co.sss.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jp.co.sss.book.bean.BookBean;

public class BookDao {

	public static List<BookBean> selectAll() {
		// Khoi tao
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		List<BookBean> bookList = new ArrayList<>();

		try {

			connection = DBManager.getConnection();

			String sql = "SELECT * FROM book ORDER BY book_id ASC";

			preparedStatement = connection.prepareStatement(sql);

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				BookBean book = new BookBean();
				book.setBookId(resultSet.getString("book_id"));
				book.setBookName(resultSet.getString("book_name"));
				book.setAuthor(resultSet.getString("author"));
				book.setPublicationDate(resultSet.getString("publication_date"));
				book.setStock(resultSet.getString("stock"));
				book.setGenre_id(resultSet.getString("genre_id"));

				bookList.add(book);
			}
//			for(BookBean book: bookList){
//				System.out.println(book.getMusiName());
//			} Kiem tra DB
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(resultSet);
			DBManager.close(preparedStatement);
			DBManager.close(connection);
		}
		return bookList;
	}

}
