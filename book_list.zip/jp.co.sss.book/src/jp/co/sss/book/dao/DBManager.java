package jp.co.sss.book.dao;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * DBManagerクラスは、
 * 作成したオリジナルなクラス
 * 最初からあるものではない
 * ○○Managerというクラスは、
 * ○○を管理するクラス名称として
 * 良く使われる。
 * DBManagerクラスは、呼び出される。
 * 単独で実行されないクラス。
 * （mainメソッドがないため）
 * staticメソッドのみなので呼び出す際は
 * DBManager.closeなどで呼ばれる
 *
 */
public class DBManager {
    /** ドライバクラス名 クラス変数 定数(oracleの場合)*/
    private static final String DRIVER = "oracle.jdbc.driver.OracleDriver";

    /** 接続するDBのURL (oracleの場合)*/
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";

    /** DB接続するためのユーザー名
     *  データベースに作成したユーザーを指定する */
    private static final String USER_NAME = "web_read_user";

    /** DB接続するためのパスワード
     * データベースに作成したパスワードを指定する */
    private static final String PASSWORD = "systemsss";

    /**
     * DBと接続する
     *
     * @return DBコネクション 戻り値
     * @throws ClassNotFoundException エクセプションの種類
     *             ドライバクラスが見つからなかった場合
     * @throws SQLException　エクセプションの種類
     *             DB接続に失敗した場合
     * すべてから参照できて(public)、
     * クラスメソッドで(static)、
     * 戻り値がConnectionで(型)、
     * 引数はなしで（）、
     * SQLExceptionが起こる可能性がある。
     * (throws)
     */
    public static Connection getConnection() throws ClassNotFoundException,
            SQLException {
        // JDBCドライバクラスをJVMに登録
        //クラスメソッド forname小文字で始まる()
        Class.forName(DRIVER);

        // DBに接続　クラスメソッド
        //(ホスト名ポート番号データベース名
        //,ユーザ名、パスワード）
        //getConnectionメソッドは
        //戻り値がConnectionと宣言してある
        Connection conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);

//        System.out.println("DBに接続しました");

        return conn;//戻り値がConnectionの為、
        //作成されたConnectionを戻す
    }

    /**
     * DBとの接続を切断する
     *
     * @param connection
     *            DBとの接続情報
     * @throws SQLException
     *             クローズ処理に失敗した場合に送出
     * 同じ名前で引数違いのメソッドを作成
     * することをオーバーロード
     * 同じ名前で作成することで、
     * 同じような機能を持つことを名前から
     * プログラマーに明示することができる。
     */
    public static void close(Connection connection) {
        if (connection != null) {
            //nullチェックしている
            //もしnullの場合、
            //インスタンスメソッド実行時に
            //エラーが出てしまう為
            try {
                connection.close();
                //DBとの通信を切断する
//                System.out.println("DBと切断しました");
            } catch (SQLException e) {
                e.printStackTrace();
                //エクセプション発生時に
                //エラー内容を表示できる
            }
        }//nullだった場合は何もしない
    }

    /**
     * PreparedStatementをクローズする
     *
     * @param preparedStatement
     *            ステートメント情報
     * @throws SQLException
     *             クローズ処理に失敗した場合に送出
     */
    public static void close(PreparedStatement preparedStatement) {
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * ResultSetをクローズする
     *
     * @param resultSet
     *            SQL検索結果
     * @throws SQLException
     *             クローズ処理に失敗した場合に送出
     */
    public static void close(ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
