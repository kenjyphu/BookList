package jp.co.sss.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jp.co.sss.book.bean.BookUserBean;

public class LoginDao {
	public static BookUserBean login(String bookUserId, String password) {

		Connection connection = null;

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		// -------------------------
		try {
			connection = DBManager.getConnection();

			String sql = "SELECT book_user_id ,password " + " FROM  book_user  "
					+ " WHERE book_user_id = ? AND password= ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, bookUserId);
			preparedStatement.setString(2, password);

			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				// Luu ID pass vao object UserSet de dem so sanh vs nguoi
				// Submit;
				BookUserBean bookUser = new BookUserBean();
				bookUser.setBookUserId(bookUserId);
				bookUser.setPassword(password);
				return bookUser;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			DBManager.close(resultSet);

			DBManager.close(preparedStatement);

			DBManager.close(connection);
		}
		return null;
	}
}
